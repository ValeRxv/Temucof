/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojos;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author valen
 */
@Entity
@Table(name = "sobregiro")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sobregiro.findAll", query = "SELECT s FROM Sobregiro s")
    , @NamedQuery(name = "Sobregiro.findByIdCuenta", query = "SELECT s FROM Sobregiro s WHERE s.idCuenta = :idCuenta")
    , @NamedQuery(name = "Sobregiro.findByIdSobregiro", query = "SELECT s FROM Sobregiro s WHERE s.idSobregiro = :idSobregiro")
    , @NamedQuery(name = "Sobregiro.findByMonto", query = "SELECT s FROM Sobregiro s WHERE s.monto = :monto")
    , @NamedQuery(name = "Sobregiro.findByEstado", query = "SELECT s FROM Sobregiro s WHERE s.estado = :estado")
    , @NamedQuery(name = "Sobregiro.findByLimite", query = "SELECT s FROM Sobregiro s WHERE s.limite = :limite")})
public class Sobregiro implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "id_cuenta")
    private String idCuenta;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "id_sobregiro")
    private String idSobregiro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "monto")
    private String monto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "limite")
    private String limite;
    @JoinColumn(name = "id_cuenta", referencedColumnName = "id_cuenta", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Cuenta cuenta;

    public Sobregiro() {
    }

    public Sobregiro(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    public Sobregiro(String idCuenta, String idSobregiro, String monto, String estado, String limite) {
        this.idCuenta = idCuenta;
        this.idSobregiro = idSobregiro;
        this.monto = monto;
        this.estado = estado;
        this.limite = limite;
    }

    public String getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    public String getIdSobregiro() {
        return idSobregiro;
    }

    public void setIdSobregiro(String idSobregiro) {
        this.idSobregiro = idSobregiro;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getLimite() {
        return limite;
    }

    public void setLimite(String limite) {
        this.limite = limite;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCuenta != null ? idCuenta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sobregiro)) {
            return false;
        }
        Sobregiro other = (Sobregiro) object;
        if ((this.idCuenta == null && other.idCuenta != null) || (this.idCuenta != null && !this.idCuenta.equals(other.idCuenta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pojos.Sobregiro[ idCuenta=" + idCuenta + " ]";
    }
    
}
