/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.ejb.Local;
import pojos.Corriente;

/**
 *
 * @author valen
 */
@Local
public interface CorrienteFacadeLocal {

    void create(Corriente corriente);

    void edit(Corriente corriente);

    void remove(Corriente corriente);

    Corriente find(Object id);

    List<Corriente> findAll();

    List<Corriente> findRange(int[] range);

    int count();
    
}
