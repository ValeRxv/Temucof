/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.ejb.Local;
import pojos.Sobregiro;

/**
 *
 * @author valen
 */
@Local
public interface SobregiroFacadeLocal {

    void create(Sobregiro sobregiro);

    void edit(Sobregiro sobregiro);

    void remove(Sobregiro sobregiro);

    Sobregiro find(Object id);

    List<Sobregiro> findAll();

    List<Sobregiro> findRange(int[] range);

    int count();
    
}
