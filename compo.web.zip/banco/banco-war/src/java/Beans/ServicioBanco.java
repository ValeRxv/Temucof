/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Modelo.ClienteFacadeLocal;
import Modelo.ComprasFacadeLocal;
import Modelo.CorrienteFacadeLocal;
import Modelo.CreditoFacadeLocal;
import Modelo.CuentaFacadeLocal;
import Modelo.DebitoFacadeLocal;
import Modelo.PagoFacadeLocal;
import Modelo.RegistroFacadeLocal;
import Modelo.SobregiroFacadeLocal;
import java.util.Calendar;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.primefaces.event.SelectEvent;
import pojos.Cliente;
import pojos.Cuenta;
import pojos.Registro;

@Named(value = "servicioBanco")
@RequestScoped
public class ServicioBanco {

    @EJB
    private SobregiroFacadeLocal sobregiroFacade;

    @EJB
    private PagoFacadeLocal pagoFacade;

    @EJB
    private DebitoFacadeLocal debitoFacade;

    @EJB
    private CreditoFacadeLocal creditoFacade;

    @EJB
    private CorrienteFacadeLocal corrienteFacade;

    @EJB
    private ComprasFacadeLocal comprasFacade;

    @EJB
    private RegistroFacadeLocal registroFacade;

    @EJB
    private CuentaFacadeLocal cuentaFacade;

    @EJB
    private ClienteFacadeLocal clienteFacade;

    private String rut;
    private String nombre;
    private String ciudad;
    private String id_cuenta;
    private String rut_e;
    private String medio_pago;
    private String id_cuenta2;
    private String fecha;
    private int total;
    private int saldo;
    private int id_registro;
    private int deposito;
    private int giro;
    private Cliente selected;
    private Cuenta selectedCuenta;
    private Cuenta selectedCuenta2;
    private Registro registro;
    private String emisor;
    private Registro selectedRegistro;

    private List<Cliente> busqueda;

    Calendar date = Calendar.getInstance();
    String dia = Integer.toString(date.get(Calendar.DATE));
    int mes = date.get(Calendar.MONTH) + 1;
    String año = Integer.toString(date.get(Calendar.YEAR));
    String fecha2 = dia + "-" + mes + "-" + año;

    public ServicioBanco() {
    }

    public List<Cliente> getCliente() {
        return clienteFacade.findAll();
    }

    public List<Cuenta> getCuenta() {
        return cuentaFacade.findAll();
    }

    public List<Registro> getRegistros() {
        return registroFacade.findAll();
    }

    public void crearCliente() {
        Cliente c = new Cliente();
        Cuenta cu = new Cuenta();

        cu.setIdCuenta(rut);
        cu.setSaldo(0);
        cuentaFacade.create(cu);

        c.setRut(rut);
        c.setNombre(nombre);
        c.setCiudad(ciudad);
        c.setIdCuenta(cu);
        clienteFacade.create(c);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Aviso", "Cliente Creado"));

    }

    public void eliminar() {

        Cliente c = clienteFacade.find(this.rut);
        Cuenta cu = cuentaFacade.find(this.rut);
        registro = new Registro();

        if (cu.getSaldo() > 0) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Aviso", "No se puede eliminar una cuenta con saldo"));
        } else {

            clienteFacade.remove(c);
            cuentaFacade.remove(cu);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Aviso", "Cliente Eliminado"));
        }
    }

    public void editar() {
        Cliente c = clienteFacade.find(this.rut);

        c.setNombre(this.nombre);
        c.setCiudad(ciudad);
        clienteFacade.edit(c);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Aviso", "Cliente modificado"));
    }

    public void limpiar() {
        this.rut = null;
        this.nombre = null;
        this.ciudad = null;

    }

    public void Select(SelectEvent event) {
        Cliente c = (Cliente) event.getObject();
        this.rut = c.getRut();
        this.nombre = c.getNombre();
        this.ciudad = c.getCiudad();
    }
    
    public void Select2(SelectEvent event) {
        Cuenta c = (Cuenta) event.getObject();
        this.id_cuenta = c.getIdCuenta();
    }

    public void eliminarRegistro() {
            int x = selectedRegistro.getIdCuenta().getSaldo();
            int a = selectedRegistro.getTotal();
            Cuenta c = new Cuenta();
            c = cuentaFacade.find(selectedRegistro.getIdCuenta());
            c.setIdCuenta(c.getIdCuenta());
            c.setSaldo(x - a);
            cuentaFacade.edit(c);
            
        registroFacade.remove(selectedRegistro);
        
    }
    public void anular() {
        registro = new Registro();
        
        selectedCuenta.setIdCuenta(selectedCuenta.getIdCuenta());
        selectedCuenta.setSaldo(selectedCuenta.getSaldo() - deposito);
        cuentaFacade.edit(selectedCuenta);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Deposito anulado"));

        registro.setIdRegistro(0);
        registro.setRutE(rut_e);
        registro.setTotal(deposito);
        registro.setIdCuenta(selectedCuenta);
        registro.setFecha(fecha2);
        registro.setOperacion("Deposito anulado");
        registro.setMedioPago(medio_pago);
        registroFacade.create(registro);
    }

    public void crearDeposito() {
        registro = new Registro();
        if (deposito <= 0) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ingrese un monto a depositar"));

        }
        selectedCuenta.setIdCuenta(selectedCuenta.getIdCuenta());
        selectedCuenta.setSaldo(selectedCuenta.getSaldo() + deposito);
        cuentaFacade.edit(selectedCuenta);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Deposito completo"));

        registro.setIdRegistro(0);
        registro.setRutE(rut_e);
        registro.setTotal(deposito);
        registro.setIdCuenta(selectedCuenta);
        registro.setFecha(fecha2);
        registro.setOperacion("Deposito");
        registro.setMedioPago(medio_pago);
        registroFacade.create(registro);

    }

    public void crearGiro() {
        registro = new Registro();
        if (selectedCuenta.getSaldo() < giro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Saldo insuficiente"));
            giro = 0;
        } else {

        }
        selectedCuenta.setIdCuenta(selectedCuenta.getIdCuenta());
        selectedCuenta.setSaldo(selectedCuenta.getSaldo() - giro);
        cuentaFacade.edit(selectedCuenta);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Giro completo"));

        registro.setIdRegistro(0);
        registro.setRutE(selectedCuenta.getIdCuenta());
        registro.setTotal(giro);
        registro.setIdCuenta(selectedCuenta);
        registro.setFecha(fecha2);
        registro.setOperacion("Giro");
        registro.setMedioPago(medio_pago);
        registroFacade.create(registro);
    }

    public RegistroFacadeLocal getRegistroFacade() {
        return registroFacade;
    }

    public void setRegistroFacade(RegistroFacadeLocal registroFacade) {
        this.registroFacade = registroFacade;
    }

    public CuentaFacadeLocal getCuentaFacade() {
        return cuentaFacade;
    }

    public void setCuentaFacade(CuentaFacadeLocal cuentaFacade) {
        this.cuentaFacade = cuentaFacade;
    }

    public ClienteFacadeLocal getClienteFacade() {
        return clienteFacade;
    }

    public void setClienteFacade(ClienteFacadeLocal clienteFacade) {
        this.clienteFacade = clienteFacade;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(String id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public String getRut_e() {
        return rut_e;
    }

    public void setRut_e(String rut_e) {
        this.rut_e = rut_e;
    }

    public String getMedio_págo() {
        return medio_pago;
    }

    public void setMedio_págo(String medio_págo) {
        this.medio_pago = medio_págo;
    }

    public String getId_cuenta2() {
        return id_cuenta2;
    }

    public void setId_cuenta2(String id_cuenta2) {
        this.id_cuenta2 = id_cuenta2;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getId_registro() {
        return id_registro;
    }

    public void setId_registro(int id_registro) {
        this.id_registro = id_registro;
    }

    public int getDeposito() {
        return deposito;
    }

    public void setDeposito(int deposito) {
        this.deposito = deposito;
    }

    public int getGiro() {
        return giro;
    }

    public void setGiro(int giro) {
        this.giro = giro;
    }

    public Cliente getSelected() {
        return selected;
    }

    public void setSelected(Cliente selected) {
        this.selected = selected;
    }

    public Cuenta getSelectedCuenta() {
        return selectedCuenta;
    }

    public void setSelectedCuenta(Cuenta selectedCuenta) {
        this.selectedCuenta = selectedCuenta;
    }

    public List<Cliente> getBusqueda() {
        return busqueda;
    }

    public void setBusqueda(List<Cliente> busqueda) {
        this.busqueda = busqueda;
    }

    public Cuenta getSelectedCuenta2() {
        return selectedCuenta2;
    }

    public void setSelectedCuenta2(Cuenta selectedCuenta2) {
        this.selectedCuenta2 = selectedCuenta2;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public Registro getRegistro() {
        return registro;
    }

    public void setRegistro(Registro registro) {
        this.registro = registro;
    }

    public String getMedio_pago() {
        return medio_pago;
    }

    public void setMedio_pago(String medio_pago) {
        this.medio_pago = medio_pago;
    }

    public Registro getSelectedRegistro() {
        return selectedRegistro;
    }

    public void setSelectedRegistro(Registro selectedRegistro) {
        this.selectedRegistro = selectedRegistro;
    }

}

